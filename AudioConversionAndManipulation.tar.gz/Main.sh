#!/bin/bash
java FileChooser
./norm.sh

