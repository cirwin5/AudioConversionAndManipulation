AudioConversionAndManipulation
==============================
    This project was created by
	Christopher  Irwin
          Brendan    Nestor
           Mike     Zielewksi
The purpose of this project is to take multiple audio files, compute the
 average RMS amplitude, and to normalize all files to that average. Some
 effects, such as fade, may also be added to files.

Extract the two gz files, then configure, make, and install them. After this,
 the script should run.
